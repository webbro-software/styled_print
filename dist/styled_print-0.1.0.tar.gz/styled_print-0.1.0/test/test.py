from styled_print import styled_print

options = {
    "color": "red",
    "styles": ["bold"],
    "bg_color": "on_white",
    "uppercase": True,
    "align": "center",
    "padding": 2,
    "border": True
}

styled_print("hello", options)
styled_print("hello", options)
styled_print("hello", options)
styled_print("hello", options)
